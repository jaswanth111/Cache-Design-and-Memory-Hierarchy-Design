import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


class sim_cache {
	public static void main(String[] args) throws Exception {
		if (args.length != 8){
			throw new Exception("Exception : Insufficient");
		}
		int BlockSize = Integer.parseInt(args[0]);
		int L1Size = Integer.parseInt(args[1]);
		int l1_Associtivity = Integer.parseInt(args[2]);
		int L2Size = Integer.parseInt(args[3]);
		int l2_Associtivity = Integer.parseInt(args[4]);
		int replacement_policy = Integer.parseInt(args[5]);
		int inclusion_property = Integer.parseInt(args[6]);
		String trace_file = args[7];

		System.out.println("BLOCK SIZE          : " + BlockSize);
		System.out.println("L1 SIZE             : " + L1Size);
		System.out.println("L1 Associtivity            : " + l1_Associtivity);
		System.out.println("L2 SIZE             : " + L2Size);
		System.out.println("L2 Associtivity            : " + l2_Associtivity);
		if (replacement_policy == 0){
			System.out.println("REPLACEMENT POLICY  : LRU");
		}else if (replacement_policy == 1){
			System.out.println("REPLACEMENT POLICY  : Pseudo-LRU");
		}else {
			System.out.println("REPLACEMENT POLICY  : Optimal");
		}
		if (inclusion_property == 0){
			System.out.println("INCLUSION PROPERTY  : non-inclusive");
		}else {
			System.out.println("INCLUSION PROPERTY  : inclusive");
		}
		String[] tr = trace_file.split("/");
		System.out.println("trace_file          : " + tr[tr.length-1]);

	
		cache L1cache = new cache(BlockSize, L1Size, l1_Associtivity, replacement_policy, trace_file);
		cache L2cache = new cache(0, 0, 0, replacement_policy, trace_file);
		if (L2Size != 0) {
			L2cache = new cache(BlockSize, L2Size, l2_Associtivity, replacement_policy, trace_file);
		}
		simulator s = new simulator(L1cache, L2cache, trace_file, L2Size);
		s.begin(inclusion_property);
		s.print_results();
	}
}


class cache {
    String[][] cache;
    int Set;
    int Asc;
    int Tag;
    int index;
    int OffSet;
    int[][] LRU;
    int[][] Dirty;
    int[][] Valid;
    ArrayList<String> opt;
    String[][] Tag_index;
    int Read = 0;
    int ReadMiss = 0;
    int Write = 0;
    int WriteMiss = 0;
    int WriteBack = 0;
    int WriteBackMiss = 0;
    int rp;
    int Count;

    
    cache (int BlockSize, int cache_size, int Associtivity, int replacement_policy, String trace) {
        if (cache_size != 0) {
            Set = cache_size / (BlockSize * Associtivity);
            Asc = Associtivity;
            rp = replacement_policy;
            cache = new String[Set][Associtivity];
            Tag_index = new String[Set][Associtivity];
            Dirty = new int[Set][Associtivity];
            Valid = new int[Set][Associtivity];
            OffSet = (int) (Math.log(BlockSize) / Math.log(2));
            index = (int) (Math.log(Set) / Math.log(2));
            Tag = 32 - index - OffSet;
            if (rp == 0 || Associtivity == 1){
                LRU = new int[Set][Associtivity];
            }else if (rp == 1) {
                int x = 0;
                int p = 1;
                float temp = 0.1f;
                while (temp != 0) {
                    temp = (float) (Associtivity / Math.pow(2, p));
                    if (temp > 0.5) {
                        x += Math.ceil(temp);
                        p += 1;
                    } else {
                        temp = 0;
                    }
                }
                LRU = new int[Set][x];
            }else if (rp == 2){
                opt = new ArrayList<>();
                Scanner trace_copy = null;
                File file_copy = new File(trace);
                try {
                    trace_copy = new Scanner(file_copy);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                while (trace_copy.hasNextLine()) {
                    String[] address = trace_copy.nextLine().split(" ");
                    String addr = address[1];
                    int v = Integer.parseInt(addr, 16);
                    String v1 = Integer.toBinaryString(v);
                    while (v1.length() < 32) {
                        v1 = "0" + v1;
                    }
                    opt.add(v1.substring(0,(Tag+index)));
                }
            }
        }
    }

    
     List GettheTag(String address) {
        List ti = new ArrayList();
        int v = Integer.parseInt(address, 16);
        String v1 = Integer.toBinaryString(v);
        while (v1.length() < 32) {
            v1 = "0" + v1;
        }
        String tg = v1.substring(0, Tag);
        String idx = v1.substring(Tag, Tag+index);
        ti.add(tg);
        ti.add(idx);
        return ti;
    }

    
     boolean Read(String address){
        boolean status = false;
        int idx = 0;
        Read++;
        List ti = GettheTag(address);
        String tg = (String) ti.get(0);
        String idxx = (String) ti.get(1);
        if (Set != 1) {
            idx = Integer.parseInt(idxx, 2);
        }

        for (int i=0; i < Asc ; i++) {
            if (Valid[idx][i] == 1){
                if (cache[idx][i].equals(tg)) {
                    if (rp == 0 || Asc == 1) {
                        updatetheLRU(idx, i);
                    }
                    else if (rp == 1) {
                        updatepseudoLRU(idx, i);
                    }
                    status = true;
                    break;
                }
            }
        }
        if (status == false) {
            ReadMiss++;
        }
        return status;
    }


   
    boolean Write(String address){
        Write++;
        int idx = 0;
        boolean status = false;
        List ti = GettheTag(address);
        String tg = (String) ti.get(0);
        String idxx = (String) ti.get(1);
        if (Set != 1) {
            idx = Integer.parseInt(idxx, 2);
        }

        for (int i=0; i < Asc ; i++) {
            if (Valid[idx][i] == 1){
                if (cache[idx][i].equals(tg)) {
                    if (rp == 0 || Asc == 1) {
                        updatetheLRU(idx, i);
                    }
                    else if (rp == 1) {
                        updatepseudoLRU(idx, i);
                    }
                    Dirty[idx][i] = 1;
                    status = true;
                    break;
                }
            }
        }
        if (status == false) {
            WriteMiss++;
        }
        return status;
    }

    
    String allocate(String address, int Counter, String op){
        boolean status = false;
        int idx = 0;
        List ti = GettheTag(address);
        String tg = (String) ti.get(0);
        String idxx = (String) ti.get(1);
        if (Set != 1) {
            idx = Integer.parseInt(idxx, 2);
        }

        for (int i = 0; i < Asc ; i++) {
            if (Valid[idx][i] == 0) {
                cache[idx][i] = tg;
                Tag_index[idx][i] = tg+idxx;
                Valid[idx][i] = 1;
                status = true;
                if (rp == 0 || Asc == 1) {
                    updatetheLRU(idx, i);
                }
                else if (rp == 1) {
                    updatepseudoLRU(idx, i);
                }
                if (op.equals("w")) {
                    Dirty[idx][i] = 1;
                }
                else {
                    Dirty[idx][i] = 0;
                }
                break;
            }
        }
        if (status == false) {
            return Takethereplacement(address, Counter, op);
        }
        return "";
    }

    
    String Takethereplacement(String address, int Counter, String op) {
        int idx = 0;
        List ti = GettheTag(address);
        String tg = (String) ti.get(0);
        String idxx = (String) ti.get(1);
        if (Set != 1) {
            idx = Integer.parseInt(idxx, 2);
        }
        String out = "";

        int r_idx = 0;
        if (rp == 0 || Asc == 1) {
            r_idx = getLRU(idx);
        }
        else if (rp == 1) {
            r_idx = getPLRU(idx);
        }
        else if (rp == 2){
            r_idx = calloptimal(idx, Counter);
        }

        if (Dirty[idx][r_idx] == 1){
            WriteBack++;
            out = Tag_index[idx][r_idx];
        }
        cache[idx][r_idx] = tg;
        Tag_index[idx][r_idx] = tg+idxx;
        Valid[idx][r_idx] = 1;

        if (rp == 0 || Asc == 1) {
            updatetheLRU(idx, r_idx);
        }
        else if (rp == 1) {
            updatepseudoLRU(idx, r_idx);
        }

        if (op.equals("w")) {
            Dirty[idx][r_idx] = 1;
        }else {
            Dirty[idx][r_idx] = 0;
        }
        return out;
    }

    
    void makeitInvalid(String address){
        int out = 0;
        int idx = 0;
        List ti = GettheTag(address);
        String tg = (String) ti.get(0);
        String idxx = (String) ti.get(1);
        if (Set != 1) {
            idx = Integer.parseInt(idxx, 2);
        }

        for (int i=0; i<Asc; i++) {
            if (cache[idx][i].equals(tg)) {
                    Valid[idx][i] = 0;
                    out = Dirty[idx][i];
                    break;
            }
        }
        if (out == 1) {
            WriteBackMiss++;
        }
    }


 void updatetheLRU(int Set, int Associtivity) {
        LRU[Set][Associtivity] = Count;
        Count++;
    }

    
    int getLRU(int Set) {
        int min_idx = 0;
        for (int i=0 ; i < Asc ; i++) {
            if (LRU[Set][i] < LRU[Set][min_idx]) {
                min_idx = i;
            }
        }
        return min_idx;
    }
	
	
	  int calloptimal(int Set, int Counter){
        int[] temp = new int[Asc];
        int Count = 0;
        for (int j=0; j<Asc; j++){
            for (int i=Counter-1; i<opt.size(); i++) {
                if (Tag_index[Set][j].equals(opt.get(i))) {
                    temp[j] = i;
                    Count++;
                    break;
                    }
                }
            if (Count == j) {
                return j;
            }
        }
        int max_idx = 0;
        for (int k=0; k<Asc; k++) {
            if (temp[k] > temp[max_idx]) {
                max_idx = k;
            }
        }
        return max_idx;
    }

    

    
    

    
    void updatepseudoLRU(int Set, int idx) {
        String x = Integer.toBinaryString(idx);
        int l = (int) Math.ceil( Math.log(Asc) / Math.log(2) );
        while (x.length() < l) {
            x = "0" + x;
        }
        String[] y = x.split("");
        int f = 1;
        for (int i=0; i<x.length(); i++) {
            LRU[Set][f-1] = Integer.parseInt(y[i]);
            if (y[i].equals("0")) {
                f = (2*f);
            }
            else {
                f = (2*f) + 1;
            }
        }
    }




 int getPLRU(int Set) {
        String x = "";
        int i = 1;
        while(i-1 < LRU[0].length) {
            x += LRU[Set][i-1];
            if (LRU[Set][i-1] == 0) {
                i = (2*i) + 1;
            } else {
                i = 2*i;
            }
        }
        String[] xx = x.split("");
        String y = "";
        for (int j=0; j<x.length(); j++) {
            if (xx[j].equals("0")){
                y += "1";
            }
            else {
                y += "0";
            }
        }
        return Integer.parseInt(y,2);
    }
    
     
}







class simulator {
    cache L1cache;
    cache L2cache;
    int l2size;
    Scanner trace_file = null;
    int Counter;

    
    simulator(cache l1, cache l2, String trace, int L2Size) {
        L1cache = l1;
        L2cache = l2;
        l2size = L2Size;
        File file = new File(trace);
        try {
            trace_file = new Scanner(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

   
    String binarytohexa(String binary){
         if(binary.length() < 32){
						int diff = 32 - binary.length();
						String pad = "";
						for(int i = 0; i < diff; ++i){
							pad = pad.concat("0");
						}
						binary = pad.concat(binary);
					}
        int dec = Integer.parseInt(binary,2);
        String hex = Integer.toString(dec,16);
        return hex;
    }


    
    void begin(int inclusion) {
        while (trace_file.hasNextLine()) {
            Counter++;
            String[] address = trace_file.nextLine().split(" ");
            String op = address[0];
            String addr = address[1];
            boolean L1status = false;
            boolean L2status;
            String out;
            String ad;

            if (op.equals("w")) {
                L1status = L1cache.Write(addr);
            }
            else if (op.equals("r")) {
                L1status = L1cache.Read(addr);
            }
            
            if (L1status == false && l2size == 0) {
                L1cache.allocate(addr, Counter, op);
            }
            else if (L1status == false && l2size != 0) {
                out = L1cache.allocate(addr, Counter, op);
                
                if (! out.equals("")) {
                    ad = binarytohexa(out);
                    L2status = L2cache.Write(ad);
                   
                    if (L2status == false){
                        L2cache.allocate(ad, Counter, "w");
                    }
                }
                L2status = L2cache.Read(addr);
             
                if (L2status == false){
                    out = L2cache.allocate(addr, Counter, op);
                    
                    if (! out.equals("") && inclusion == 1) {
                        ad = binarytohexa(out);
                        L1cache.makeitInvalid(ad);
                    }
                }
            }
        }
    }

   
    void print_results() {
        System.out.println("====== L1 contents ======");
        print_content(L1cache);
        if (l2size !=0) {
            System.out.println("====== L2 contents ======");
            print_content(L2cache);
        }
      
        System.out.println("a. number of L1 Reads        : " + L1cache.Read);
        System.out.println("b. number of L1 Read misses  : " + L1cache.ReadMiss);
        System.out.println("c. number of L1 Writes       : " + L1cache.Write);
        System.out.println("d. number of L1 Write misses : " + L1cache.WriteMiss);
        float l1_miss_rate = (float) (L1cache.ReadMiss + L1cache.WriteMiss)/
                (float) (L1cache.Read + L1cache.Write);
        System.out.println("e. L1 miss rate              : " + l1_miss_rate);
        System.out.println("f. number of L1 Writebacks   : " + L1cache.WriteBack);
        int traffic = L1cache.ReadMiss + L1cache.WriteMiss + L1cache.WriteBack;
        if (l2size != 0) {
            System.out.println("g. number of L2 Reads        : " + L2cache.Read);
            System.out.println("h. number of L2 Read misses  : " + L2cache.ReadMiss);
            System.out.println("i. number of L2 Writes       : " + L2cache.Write);
            System.out.println("j. number of L2 Write misses : " + L2cache.WriteMiss);
            float l2_miss_rate = (float) (L2cache.ReadMiss)/ (float) (L2cache.Read);
            System.out.println("k. L2 miss rate              : " + l2_miss_rate);
            System.out.println("l. number of L2 Writebacks   : " + L2cache.WriteBack);
            traffic = L2cache.ReadMiss + L2cache.WriteMiss + L2cache.WriteBack + L1cache.WriteBackMiss;
        }
        else {
            System.out.println("g. number of L2 Reads        : " + 0);
            System.out.println("h. number of L2 Read misses  : " + 0);
            System.out.println("i. number of L2 Writes       : " + 0);
            System.out.println("j. number of L2 Write misses : " + 0);
            System.out.println("k. L2 miss rate              : " + 0);
            System.out.println("l. number of L2 Writebacks   : " + 0);
        }
        System.out.println("m. total memory traffic      : " + traffic);
    }

    void print_content(cache c) {
        for (int i=0; i<c.Set; i++) {
            System.out.print("Set\t"+i+" : ");
            for (int j=0; j< c.Asc; j++) {
                if (c.Valid[i][j] == 1) {
                    int dec = Integer.parseInt(c.cache[i][j],2);
                    String hex = Integer.toString(dec,16);
                    System.out.print(hex + " ");
                    if (c.Dirty[i][j] == 1) {
                        System.out.print("D\t");
                    }else {
                        System.out.print(" \t");
                    }
                }
            }
            System.out.print("\n");
        }
    }
}













